/* 
public class TipoArrayList extends Tipo{
        //faltan lineas
        public Objeto generarCodigoInstancia(Instancia instancia,String metodo, Objeto[] param) throws Exception{
        //faltan lineas
        etiqC=newEtiq();
        etiqF=newEtiq();

        if(this.getTipoBase() instanceof TipoArray){
            aDes=new VariableArray(va.getNombre(), vIndD, va.getBloque()algooo);
        }else{
            aDes=new VariableArray(va.getNombre(),vIndD,va.getBloque()algoo, new TipoEArray(newNomObj(),algooo));
        }

        PLXC.out.println("if ("+par.getIDC()+" < 0) goto "+ algooo);
        PLXC.out.println("if ("+par.getIDC()+" < "+ this.getSize() algooo);
        PLXC.out.println("error: ");
        PLXC.out.println("halt: ");
        PLXC.out.println(etiqC+";");
        PLXC.out.println(vIndD+ " = "+va.getVDesplazamiento()+algooo);
        vSizeD=(Variable) aDes.getTipo().generarCodigoMetodo(Metodo,algooo);
        PLXC.out.println(vDesp+" = "+vSizeD.getIDC()+"algo"algooo);
        PLXC.out.println(vIndD+" = "+vIndD+"algo"+vDesp+";");            
        PLXC.out.println("goto "+etiqC+";");
        

        return param[0];
        //faltan lineas
            

    }

        @Override
        public Objeto generarCodigoMetodo(String metodo, Objeto[] param) throws Exception {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'generarCodigoMetodo'");
        }
}
        */
