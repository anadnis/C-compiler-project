public final class Metodos {
    public static final String ASIGNA = "$asigna";
    public static final String SUMA = "$suma";
    public static final String RESTA = "$resta";
    public static final String MULT = "$multiplicacion";	
    public static final String DIVID = "$division";
    public static final String OPUESTO = "$opuesto";
    public static final String SIGUIENTE = "$siguiente";
    public static final String ANTERIOR = "$anterior";
    public static final String MENOR = "$menor";
    public static final String MENORIG = "$menorig";
    public static final String MAYOR = "$mayor";
    public static final String MAYORIG = "$mayorig";
    public static final String IGUAL = "$igual";
    public static final String DIFERENTE = "$diferente";
    public static final String YLOG = "$ylog";
    public static final String OLOG = "$olog";
    public static final String NLOG = "$nlog";
    public static final String CAST = "$cast";
    public static final String RESTO = "$resto";
    public static final String CONSTLITERAL = "$constliteral"; 
    public static final String PONERETIQ = "$poneretiq";
    public static final String SALTARETIQ = "$saltaretiq";
    public static final String IMPRIMIR = "$print";
    public static final String CONSTRUCTORCOPIA = "$constructorcopia";

} //esta todo 